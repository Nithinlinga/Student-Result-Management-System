<?php
$conn = mysqli_connect("localhost", "root", "", "admin_cre");
?>